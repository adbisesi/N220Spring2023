
for (let i = 0; i < 5; i++) {
    const button = document.getElementById("div")
  
      console.log(i)

      if (i>5) {
        button = "revealed";
      }
    }
    
  