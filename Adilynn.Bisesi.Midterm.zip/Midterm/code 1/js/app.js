let div = document.getElementById("div")
function mcgriddle(){
    div.innerHTML += "cirro and cumulo and nimbo and strato and"
}


for (var x=0; x<=5; x++) {
    if (x === 0) {
            console.log(x =  "Cirro and");
    }
    else if (x === 1) {
            console.log(x = " cumulo and");   
    }
    else if (x === 2) {
            console.log(x + "nimbo and");
    }
    
    else if (x === 3) {
        console.log(x = "strato and");}


    



}

